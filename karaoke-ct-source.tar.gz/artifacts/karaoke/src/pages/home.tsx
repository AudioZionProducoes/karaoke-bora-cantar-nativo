import { useState, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { Play, Music, Mic2, ListPlus, Check, Monitor, QrCode, Search, Settings, FolderOpen } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { useSearchMusicas, useGetMusicasStats } from "@workspace/api-client-react";
import { useDebounce } from "@/hooks/use-debounce";
import { Layout } from "@/components/layout";
import { useQueue, type QueueItem } from "@/contexts/queue-context";
import { useToast } from "@/hooks/use-toast";
import { AddToQueueDialog, type PendingQueueItem } from "@/components/add-to-queue-dialog";
import { useSession } from "@/hooks/use-session";
import { useSearch } from "@/contexts/search-context";
import { useLocalMusic } from "@/contexts/local-music-context";

export default function Home() {
  const { addToQueue, isInQueue, queue } = useQueue();
  const { session, createSession } = useSession();
  const { selectFolder } = useLocalMusic();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { searchTerm, setSearchTerm } = useSearch();
  const debouncedSearch = useDebounce(searchTerm, 300);
  const [page, setPage] = useState(1);
  const [pendingItem, setPendingItem] = useState<PendingQueueItem | null>(null);
  const [startingSession, setStartingSession] = useState(false);

  useMemo(() => { setPage(1); }, [debouncedSearch]);

  const { data: stats } = useGetMusicasStats();
  const { data: searchResults, isLoading } = useSearchMusicas({ q: debouncedSearch, page, limit: 24 });

  async function handleStartTV() {
    setStartingSession(true);
    const id = await createSession("Karaoke CT");
    setStartingSession(false);
    if (id) navigate(`/tv/${id}`);
  }

  function openQueueDialog(m: PendingQueueItem) {
    if (queue.length >= 30) {
      toast({ title: "Fila cheia", description: "A fila já tem 30 músicas.", variant: "destructive" });
      return;
    }
    if (isInQueue(m.id)) {
      toast({ title: "Já na fila", description: `"${m.musica}" já está na lista de espera.` });
      return;
    }
    setPendingItem(m);
  }

  function handleConfirmQueue(singerName: string) {
    if (!pendingItem) return;
    addToQueue({ ...pendingItem, singerName });
    toast({ title: "Adicionada à fila ✓", description: `"${pendingItem.musica}" entrou na fila para ${singerName}.` });
    setPendingItem(null);
  }

  return (
    <Layout>
      <AddToQueueDialog
        item={pendingItem}
        onConfirm={handleConfirmQueue}
        onCancel={() => setPendingItem(null)}
      />

      <div className="flex flex-col items-center pt-4 pb-4 max-w-3xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-2 shadow-[0_0_15px_rgba(250,204,21,0.15)] dark:shadow-[0_0_15px_rgba(250,204,21,0.25)]">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
          </span>
          {stats ? `${stats.totalSongs.toLocaleString("pt-BR")} músicas disponíveis` : "Carregando catálogo..."}
        </div>

        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground drop-shadow-sm">
          Faça de sua Festa um Grande Evento.
        </h1>
        <p className="text-lg text-muted-foreground max-w-xl">
          Busque no maior catálogo de karaokê. Músicas de alta qualidade, sem espera.
        </p>

        {/* TV Mode button */}
        <div className="flex gap-3">
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/90 shadow-[0_0_20px_rgba(168,85,247,0.3)] dark:shadow-[0_0_20px_rgba(250,204,21,0.3)] transition-all"
            onClick={handleStartTV}
            disabled={startingSession}
          >
            <Monitor className="h-5 w-5 mr-2" />
            {startingSession ? "Iniciando..." : "Modo TV + Controle Remoto"}
          </Button>
          {session && (
            <Button
              variant="outline"
              size="lg"
              className="border-primary/50 text-primary hover:bg-primary/10 dark:border-yellow-400/50 dark:text-yellow-400 dark:hover:bg-yellow-400/10"
              onClick={() => navigate(`/tv/${session.id}`)}
            >
              <QrCode className="h-5 w-5 mr-2" />
              Entrar na Sessão {session.id}
            </Button>
          )}
        </div>
      </div>

      <div className="mt-2 space-y-4">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-semibold tracking-tight flex items-center gap-2 shrink-0">
            <Music className="h-5 w-5 text-primary dark:text-yellow-400" />
            {debouncedSearch ? "Resultados da Busca" : "Catálogo em Destaque"}
          </h2>

          {/* Search bar next to title */}
          <div className="flex-1 max-w-md">
            <div className="relative group">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-lg transition-all group-hover:bg-primary/30 group-focus-within:bg-primary/40 dark:bg-yellow-400/20 dark:group-hover:bg-yellow-400/30 dark:group-focus-within:bg-yellow-400/40 -z-10"></div>
              <div className="relative flex items-center w-full">
                <Search className="absolute left-3.5 h-4 w-4 text-white dark:text-black" />
                <Input
                  type="text"
                  placeholder="Buscar música..."
                  className="w-full h-9 pl-9 pr-4 rounded-full bg-black border-white/30 text-white placeholder:text-white/60 text-sm shadow-sm focus-visible:ring-white focus-visible:border-white dark:bg-[hsl(55,100%,50%)] dark:border-black/30 dark:text-black dark:placeholder:text-black/60 dark:focus-visible:ring-black dark:focus-visible:border-black transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          {searchResults && (
            <span className="text-sm text-muted-foreground shrink-0">{searchResults.total.toLocaleString("pt-BR")} encontradas</span>
          )}

          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={selectFolder}
              className="text-xs font-medium text-muted-foreground hover:text-foreground border-border/30 bg-muted/40 rounded-full px-3 py-1.5 h-auto gap-1"
            >
              <FolderOpen className="h-3.5 w-3.5" />
              <span>Pasta</span>
            </Button>
            <Link href="/admin" className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 bg-muted/40 border border-border/30 rounded-full px-3 py-1.5">
              <Settings className="h-3.5 w-3.5" />
              <span>Admin</span>
            </Link>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <Card key={i} className="bg-card/50 border-border/40 overflow-hidden">
                <CardContent className="p-5 flex flex-col h-full gap-4">
                  <div className="space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                  <Skeleton className="h-10 w-full mt-auto" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : searchResults?.data.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="bg-muted/30 p-4 rounded-full mb-4">
              <Mic2 className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-medium">Nenhuma música encontrada</h3>
            <p className="text-muted-foreground mt-2">Tente um termo de busca diferente</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {searchResults?.data.map((musica) => (
                <Card key={musica.id} className="group bg-card border-border/40 hover:border-primary/50 dark:hover:border-yellow-400/50 transition-all hover:shadow-[0_0_20px_rgba(168,85,247,0.1)] dark:hover:shadow-[0_0_20px_rgba(250,204,21,0.15)] overflow-hidden flex flex-col h-full">
                  <CardContent className="p-5 flex flex-col h-full gap-4 relative">
                    <div className="space-y-1.5 flex-1 relative z-10">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-semibold text-lg line-clamp-1 group-hover:text-primary transition-colors" title={musica.musica}>
                          {musica.musica}
                        </div>
                        <span className="shrink-0 text-xs font-mono text-primary/70 bg-primary/10 border border-primary/20 rounded px-1.5 py-0.5">
                          #{musica.id}
                        </span>
                      </div>
                      <div className="text-muted-foreground font-medium text-sm line-clamp-1" title={musica.artista}>
                        {musica.artista}
                      </div>
                      {musica.inicio && (
                        <div className="text-xs text-muted-foreground/70 mt-3 italic line-clamp-2 pl-2 border-l-2 border-primary/30">
                          "{musica.inicio}"
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 mt-4">
                      <Link href={`/player/${musica.id}`} className="flex-1">
                        <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 group-hover:shadow-[0_0_15px_rgba(168,85,247,0.3)] dark:group-hover:shadow-[0_0_15px_rgba(250,204,21,0.4)] transition-all z-10 relative">
                          <Play className="h-4 w-4 mr-2" />
                          Cantar Agora
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="icon"
                        title="Adicionar à fila"
                        className={`shrink-0 border-border/50 transition-all z-10 relative ${isInQueue(musica.id) ? "text-emerald-400 border-emerald-400/40 bg-emerald-400/10 hover:bg-emerald-400/20" : "text-muted-foreground hover:text-foreground hover:border-primary/50"}`}
                        onClick={() => openQueueDialog({ id: musica.id, musica: musica.musica, artista: musica.artista })}
                      >
                        {isInQueue(musica.id) ? <Check className="h-4 w-4" /> : <ListPlus className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {searchResults && searchResults.totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 pt-8">
                <Button variant="outline" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                  Anterior
                </Button>
                <div className="text-sm font-medium px-4">
                  Página {page} de {searchResults.totalPages}
                </div>
                <Button variant="outline" disabled={page === searchResults.totalPages} onClick={() => setPage(p => p + 1)}>
                  Próxima
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}
